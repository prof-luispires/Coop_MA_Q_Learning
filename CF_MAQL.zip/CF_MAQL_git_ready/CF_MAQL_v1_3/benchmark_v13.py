from __future__ import annotations
import argparse, json, time
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score, matthews_corrcoef, balanced_accuracy_score, average_precision_score, roc_auc_score

from .benchmark_v12_final import prepare_seed
from .benchmark_v12 import train_coordinator, predict_coordinator, metrics, famrec

SEEDS_DEFAULT='11,22,33,44,55'


def binary_from_threshold(score, threshold):
    return (np.asarray(score) >= float(threshold)).astype(np.int8)


def threshold_metrics(y, score, threshold):
    yp=binary_from_threshold(score, threshold)
    m=metrics(y, yp, score)
    m['threshold']=float(threshold)
    return m, yp


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--csv', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--episodes', type=int, default=8)
    ap.add_argument('--seeds', default=SEEDS_DEFAULT)
    ap.add_argument('--coord-alpha', type=float, default=0.01)
    ap.add_argument('--coord-episodes', type=int, default=12)
    ap.add_argument('--temperature', type=float, default=0.50)
    ap.add_argument('--min-val-recall', type=float, default=0.995)
    ap.add_argument('--threshold-min', type=float, default=0.50)
    ap.add_argument('--threshold-max', type=float, default=0.95)
    ap.add_argument('--threshold-step', type=float, default=0.0025)
    args=ap.parse_args()

    seeds=[int(x) for x in args.seeds.split(',') if x.strip()]
    out=Path(args.out); out.mkdir(parents=True, exist_ok=True)

    prepared={}
    pred_cache={}
    for seed in seeds:
        print('Preparing v1.3 seed', seed, flush=True)
        p=prepare_seed(args.csv, seed, args.episodes, temp=args.temperature)
        prepared[seed]=p
        cfg,dm,sp,views,pa,pc,W,dims,qc,qv,qt,hr,ht=p
        Wc,chr=train_coordinator(qc,sp.y_train[pc],np.ones(len(pc),dtype=np.float64),
                                 args.coord_episodes,args.coord_alpha,1.0,0.05,0.90,
                                 cfg.td_clip,cfg.weight_clip,cfg.interaction_q_scale,args.temperature,seed)
        ypv,scv,av=predict_coordinator(qv,Wc,cfg.interaction_q_scale,args.temperature)
        ypt,sct,at=predict_coordinator(qt,Wc,cfg.interaction_q_scale,args.temperature)
        pred_cache[seed]={'Wc':Wc,'chr':chr,'val_score':scv,'test_score':sct,
                          'val_default':ypv,'test_default':ypt,'test_actions':at}

    thresholds=np.arange(args.threshold_min,args.threshold_max+args.threshold_step/2,args.threshold_step)
    valrows=[]
    for th in thresholds:
        for seed in seeds:
            sp=prepared[seed][2]; score=pred_cache[seed]['val_score']
            mm,_=threshold_metrics(sp.y_val,score,th)
            valrows.append({'threshold':float(th),'seed':seed,**{k:mm[k] for k in ['precision','recall','f1','mcc','balanced_accuracy','pr_auc','roc_auc','fpr','fnr']}})
    vdf=pd.DataFrame(valrows); vdf.to_csv(out/'threshold_validation.csv',index=False)
    vs=vdf.groupby('threshold',as_index=False).agg(
        precision_mean=('precision','mean'), recall_mean=('recall','mean'), recall_std=('recall','std'),
        f1_mean=('f1','mean'), f1_std=('f1','std'), mcc_mean=('mcc','mean'), mcc_std=('mcc','std'),
        ba_mean=('balanced_accuracy','mean'), ba_std=('balanced_accuracy','std'),
        fpr_mean=('fpr','mean'), fpr_std=('fpr','std'), fnr_mean=('fnr','mean'), fnr_std=('fnr','std'),
        pr_auc_mean=('pr_auc','mean'), roc_auc_mean=('roc_auc','mean'))
    feasible=vs[vs.recall_mean >= args.min_val_recall].copy()
    if len(feasible)==0:
        feasible=vs.copy()
        selection_note='No threshold satisfied recall constraint; selected max mean validation MCC.'
    else:
        selection_note=f'Selected among thresholds with mean validation recall >= {args.min_val_recall:.4f}.'
    feasible=feasible.sort_values(['mcc_mean','ba_mean','f1_mean','fpr_mean'], ascending=[False,False,False,True])
    best=feasible.iloc[0]
    threshold=float(best.threshold)
    vs['selected']=np.isclose(vs.threshold, threshold)
    vs.to_csv(out/'threshold_validation_summary.csv',index=False)
    (out/'selected_threshold.json').write_text(json.dumps({
        'threshold':threshold,
        'min_mean_validation_recall':args.min_val_recall,
        'selection':'max mean validation MCC; tie-break balanced accuracy, F1, then lower FPR',
        'note':selection_note,
        'coord_alpha':args.coord_alpha,
        'coord_episodes':args.coord_episodes,
        'confidence_temperature':args.temperature,
        'seeds':seeds
    },indent=2))
    print('Selected threshold',threshold,'val MCC',best.mcc_mean,'val recall',best.recall_mean,'val FPR',best.fpr_mean,flush=True)

    rows=[]; famrows=[]
    for seed in seeds:
        sp=prepared[seed][2]; score=pred_cache[seed]['test_score']
        # default v1.2 operating point = score >= 0.5
        for name,th in [('CF-MAQL-v1.2',0.5),('CF-MAQL-v1.3',threshold)]:
            mm,yp=threshold_metrics(sp.y_test,score,th)
            mm.update(configuration=name,seed=seed,threshold=th,coord_alpha=args.coord_alpha,
                      coord_episodes=args.coord_episodes,temperature=args.temperature)
            rows.append(mm)
            fr=famrec(sp.y_test,yp,sp.family_test)
            for f,r in fr.items(): famrows.append({'configuration':name,'seed':seed,'family':f,'recall':r})
            print(name,seed,'thr',round(th,4),'F1',round(mm['f1'],4),'MCC',round(mm['mcc'],4),
                  'BA',round(mm['balanced_accuracy'],4),'Recall',round(mm['recall'],4),'FPR',round(mm['fpr'],4),flush=True)

    rdf=pd.DataFrame(rows); rdf.to_csv(out/'per_run_metrics.csv',index=False)
    fdf=pd.DataFrame(famrows); fdf.to_csv(out/'family_recall.csv',index=False)
    cols=['precision','recall','f1','mcc','balanced_accuracy','pr_auc','roc_auc','fpr','fnr']
    summ=[]
    for c,g in rdf.groupby('configuration',sort=False):
        rr={'configuration':c,'runs':len(g),'threshold':g.threshold.iloc[0]}
        for col in cols:
            rr[col+'_mean']=g[col].mean(); rr[col+'_std']=g[col].std(ddof=1)
        summ.append(rr)
    pd.DataFrame(summ).to_csv(out/'summary_metrics.csv',index=False)

    base=rdf[rdf.configuration=='CF-MAQL-v1.2'].set_index('seed')
    cal=rdf[rdf.configuration=='CF-MAQL-v1.3'].set_index('seed')
    comps=[]
    for metric in ['precision','recall','f1','mcc','balanced_accuracy','pr_auc','roc_auc','fpr','fnr']:
        d=cal[metric]-base[metric]
        beneficial = -d if metric in ['fpr','fnr'] else d
        comps.append({'comparison':'CF-MAQL-v1.3 - CF-MAQL-v1.2','metric':metric,
                      'mean_difference':d.mean(),'std_difference':d.std(ddof=1),
                      'wins':int((beneficial>0).sum()),'ties':int((beneficial==0).sum()),'losses':int((beneficial<0).sum())})
    pd.DataFrame(comps).to_csv(out/'paired_differences.csv',index=False)
    fsum=fdf.groupby(['configuration','family'],as_index=False).agg(recall_mean=('recall','mean'),recall_std=('recall','std'))
    fsum.to_csv(out/'family_recall_summary.csv',index=False)

    (out/'benchmark_notes.txt').write_text(
        'CF-MAQL v1.3 decision-threshold calibration benchmark. The v1.2 architecture, local agents, coordinator, preprocessing, data partitions, and coordinator hyperparameters are frozen. '
        'Only the binary operating threshold applied to the coordinator attack score is calibrated. Threshold selection uses validation data only, aggregated across seeds, '
        f'with a mean validation recall constraint >= {args.min_val_recall:.4f}; among feasible thresholds, mean validation MCC is maximized, with balanced accuracy, F1, and lower FPR as tie-breaks. '
        'The test set is untouched until the selected global threshold is frozen. gamma=0 remains unchanged because RT-IoT2022 does not provide a defensible action-dependent temporal transition model.\n')

if __name__=='__main__': main()
