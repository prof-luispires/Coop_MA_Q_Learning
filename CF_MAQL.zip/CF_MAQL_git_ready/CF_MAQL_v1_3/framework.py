from __future__ import annotations
from collections import deque, Counter
import numpy as np
from sklearn.metrics import (
    precision_score, recall_score, f1_score, matthews_corrcoef,
    balanced_accuracy_score, average_precision_score, roc_auc_score,
    confusion_matrix
)
from .agents import LinearQAgent
from .config import FrameworkConfig, ACTIONS, ACTION_TO_BINARY

class SharedContext:
    def __init__(self, window: int = 50):
        self.window = window
        self.recent_decisions = deque(maxlen=window)
        self.prev_mean_conf = 0.0
        self.prev_action = 0

    def vector(self) -> np.ndarray:
        attack_rate = float(np.mean(self.recent_decisions)) if self.recent_decisions else 0.0
        return np.array([
            attack_rate,
            self.prev_mean_conf,
            self.prev_action / 3.0,
        ], dtype=np.float32)

    def update(self, global_action: int, mean_conf: float):
        self.recent_decisions.append(ACTION_TO_BINARY[global_action])
        self.prev_mean_conf = float(mean_conf)
        self.prev_action = int(global_action)

class CFMAQL:
    def __init__(self, view_dims: dict[str, int], cfg: FrameworkConfig,
                 fusion: str = "confidence", cooperative_reward: bool = True):
        self.cfg = cfg
        self.fusion = fusion
        self.cooperative_reward = cooperative_reward
        self.agent_names = list(view_dims)
        self.agents = {
            name: LinearQAgent(
                input_dim=dim + 3,
                alpha=cfg.alpha, gamma=cfg.gamma,
                seed=cfg.seed + i,
                td_clip=cfg.td_clip, weight_clip=cfg.weight_clip,
            )
            for i, (name, dim) in enumerate(view_dims.items())
        }

    def _state(self, local_x: np.ndarray, context: np.ndarray) -> np.ndarray:
        return np.concatenate([local_x, context]).astype(np.float32)

    def _reward(self, y: int, action: int) -> float:
        return float(self.cfg.reward_matrix[action][int(y)])

    def _fuse(self, states: dict[str, np.ndarray]):
        q = {name: self.agents[name].q_values(states[name]) for name in self.agent_names}
        conf_raw = np.array([self.agents[name].confidence(states[name]) for name in self.agent_names])
        if self.fusion == "uniform" or conf_raw.sum() <= 1e-12:
            weights = np.ones(len(self.agent_names), dtype=float) / len(self.agent_names)
        else:
            weights = conf_raw / conf_raw.sum()
        q_global = sum(weights[i] * q[name] for i, name in enumerate(self.agent_names))
        return q_global, q, weights, conf_raw

    def fit(self, views: dict[str, np.ndarray], y: np.ndarray, verbose: bool = True):
        n = len(y)
        history = []
        epsilon = self.cfg.epsilon_start
        for ep in range(self.cfg.episodes):
            ctx = SharedContext(self.cfg.context_window)
            rewards, tds = [], []
            for t in range(n):
                cvec = ctx.vector()
                states = {name: self._state(views[name][t], cvec) for name in self.agent_names}
                local_actions = {name: self.agents[name].action(states[name], epsilon) for name in self.agent_names}
                qg, _, weights, conf_raw = self._fuse(states)
                # Global exploration avoids deterministic lock-in in early episodes.
                if np.random.default_rng(self.cfg.seed + ep + t).random() < epsilon:
                    global_action = int(np.random.default_rng(self.cfg.seed + 997 + ep + t).integers(4))
                else:
                    global_action = int(np.argmax(qg))
                global_reward = self._reward(y[t], global_action)
                mean_conf = float(np.mean(conf_raw))
                # Build next context after global decision.
                ctx.update(global_action, mean_conf)
                next_cvec = ctx.vector()
                for name in self.agent_names:
                    local_reward = self._reward(y[t], local_actions[name])
                    reward = (
                        self.cfg.lambda_local * local_reward + (1-self.cfg.lambda_local) * global_reward
                        if self.cooperative_reward else local_reward
                    )
                    next_state = None
                    terminal = (t == n-1)
                    if not terminal:
                        next_state = self._state(views[name][t+1], next_cvec)
                    td = self.agents[name].update(
                        states[name], local_actions[name], reward, next_state, terminal
                    )
                    tds.append(abs(td))
                rewards.append(global_reward)
            rec = {
                "episode": ep + 1,
                "epsilon": epsilon,
                "mean_global_reward": float(np.mean(rewards)),
                "mean_abs_td": float(np.mean(tds)),
            }
            history.append(rec)
            if verbose:
                print(rec)
            epsilon = max(self.cfg.epsilon_min, epsilon * self.cfg.epsilon_decay)
        return history

    def predict(self, views: dict[str, np.ndarray]):
        n = len(next(iter(views.values())))
        ctx = SharedContext(self.cfg.context_window)
        actions, preds, scores, weights_all, rewards_dummy = [], [], [], [], []
        for t in range(n):
            cvec = ctx.vector()
            states = {name: self._state(views[name][t], cvec) for name in self.agent_names}
            qg, _, weights, conf_raw = self._fuse(states)
            action = int(np.argmax(qg))
            # Continuous attack score: best attack action vs best benign action.
            attack_q = float(np.max(qg[2:4]))
            benign_q = float(np.max(qg[0:2]))
            margin = np.clip(attack_q - benign_q, -30, 30)
            score = float(1.0 / (1.0 + np.exp(-margin)))
            pred = ACTION_TO_BINARY[action]
            actions.append(action); preds.append(pred); scores.append(score); weights_all.append(weights)
            ctx.update(action, float(np.mean(conf_raw)))
        return {
            "actions": np.asarray(actions),
            "pred": np.asarray(preds),
            "score": np.asarray(scores),
            "weights": np.asarray(weights_all),
        }

    def evaluate(self, views: dict[str, np.ndarray], y: np.ndarray, families=None):
        out = self.predict(views)
        yp, score = out["pred"], out["score"]
        tn, fp, fn, tp = confusion_matrix(y, yp, labels=[0, 1]).ravel()
        result = {
            "precision": precision_score(y, yp, zero_division=0),
            "recall": recall_score(y, yp, zero_division=0),
            "f1": f1_score(y, yp, zero_division=0),
            "mcc": matthews_corrcoef(y, yp),
            "balanced_accuracy": balanced_accuracy_score(y, yp),
            "pr_auc": average_precision_score(y, score),
            "roc_auc": roc_auc_score(y, score),
            "fpr": fp / (fp + tn) if (fp + tn) else 0.0,
            "fnr": fn / (fn + tp) if (fn + tp) else 0.0,
            "tp": int(tp), "tn": int(tn), "fp": int(fp), "fn": int(fn),
            "actions": dict(Counter(ACTIONS[int(a)] for a in out["actions"])),
            "mean_agent_weights": dict(zip(self.agent_names, out["weights"].mean(axis=0).tolist())),
        }
        if families is not None:
            fam_result = {}
            families = np.asarray(families)
            for fam in np.unique(families):
                mask = families == fam
                if y[mask].sum() == 0:
                    continue
                fam_result[str(fam)] = float(np.mean(yp[mask] == 1))
            result["attack_family_recall"] = fam_result
        return result
