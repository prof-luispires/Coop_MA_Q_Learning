from __future__ import annotations
import numpy as np
import pandas as pd
from dataclasses import dataclass
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.feature_selection import mutual_info_classif
from .config import AGENT_FEATURES, BENIGN_CLASSES, FrameworkConfig

@dataclass
class SplitData:
    train_idx: np.ndarray
    val_idx: np.ndarray
    test_idx: np.ndarray
    y_train: np.ndarray
    y_val: np.ndarray
    y_test: np.ndarray
    family_train: np.ndarray
    family_val: np.ndarray
    family_test: np.ndarray

class AgentPreprocessor:
    def __init__(self, agent_name: str, cfg: FrameworkConfig):
        self.agent_name = agent_name
        self.cfg = cfg
        self.features = list(AGENT_FEATURES[agent_name])
        self.categorical = [c for c in self.features if c in ("proto", "service")]
        self.numeric = [c for c in self.features if c not in self.categorical]
        self.log_cols = []
        self.keep_numeric = []
        self.scaler = StandardScaler()
        self.encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False) if self.categorical else None
        self.feature_names_out_ = []

    def _select_numeric(self, x: pd.DataFrame, y: np.ndarray) -> list[str]:
        cols = [c for c in self.numeric if x[c].nunique(dropna=False) > 1]
        if not self.cfg.selected_features or len(cols) <= 1:
            return cols
        corr = x[cols].corr().abs()
        # MI is used only to decide which member of a highly correlated pair to keep.
        # To keep the repeated-seed benchmark tractable, estimate MI on a deterministic
        # training-only balanced subsample (up to 20,000 observations).
        rng = np.random.default_rng(self.cfg.seed)
        idx0 = np.flatnonzero(y == 0)
        idx1 = np.flatnonzero(y == 1)
        per = min(10000, len(idx0), len(idx1))
        if per > 0:
            mi_idx = np.concatenate([rng.choice(idx0, per, replace=False), rng.choice(idx1, per, replace=False)])
        else:
            mi_idx = np.arange(min(20000, len(y)))
        mi = mutual_info_classif(x.iloc[mi_idx][cols].fillna(0).to_numpy(), y[mi_idx], random_state=self.cfg.seed)
        mi_map = dict(zip(cols, mi))
        removed = set()
        for i, c1 in enumerate(cols):
            if c1 in removed:
                continue
            for c2 in cols[i+1:]:
                if c2 in removed:
                    continue
                if corr.loc[c1, c2] > self.cfg.corr_threshold:
                    if mi_map[c1] >= mi_map[c2]:
                        removed.add(c2)
                    else:
                        removed.add(c1)
                        break
        return [c for c in cols if c not in removed]

    def fit(self, x: pd.DataFrame, y: np.ndarray):
        self.keep_numeric = self._select_numeric(x, y)
        skew = x[self.keep_numeric].skew(numeric_only=True)
        self.log_cols = [
            c for c in self.keep_numeric
            if abs(float(skew.get(c, 0.0))) > self.cfg.skew_threshold and (x[c].min() >= 0)
        ]
        xn = x[self.keep_numeric].astype(float).copy()
        if self.log_cols:
            xn[self.log_cols] = np.log1p(xn[self.log_cols])
        self.scaler.fit(xn)
        cat_names = []
        if self.encoder is not None:
            self.encoder.fit(x[self.categorical].astype(str))
            cat_names = self.encoder.get_feature_names_out(self.categorical).tolist()
        self.feature_names_out_ = list(self.keep_numeric) + cat_names
        return self

    def transform(self, x: pd.DataFrame) -> np.ndarray:
        xn = x[self.keep_numeric].astype(float).copy()
        if self.log_cols:
            xn[self.log_cols] = np.log1p(xn[self.log_cols])
        zn = self.scaler.transform(xn).astype(np.float32)
        if self.encoder is None:
            return zn
        zc = self.encoder.transform(x[self.categorical].astype(str)).astype(np.float32)
        return np.hstack([zn, zc]).astype(np.float32)

class RTIoT2022DataModule:
    def __init__(self, csv_path: str, cfg: FrameworkConfig):
        self.csv_path = csv_path
        self.cfg = cfg
        self.df = pd.read_csv(csv_path)
        self._validate()
        self.y = (~self.df["Attack_type"].isin(BENIGN_CLASSES)).astype(np.int8).to_numpy()
        self.families = self.df["Attack_type"].astype(str).to_numpy()
        self.preprocessors = {}
        self.split: SplitData | None = None

    def _validate(self):
        required = {"Attack_type"} | set().union(*[set(v) for v in AGENT_FEATURES.values()])
        missing = required - set(self.df.columns)
        if missing:
            raise ValueError(f"Missing columns: {sorted(missing)}")

    def make_split(self) -> SplitData:
        idx = np.arange(len(self.df))
        train_idx, temp_idx = train_test_split(
            idx, test_size=(1-self.cfg.train_size), stratify=self.families, random_state=self.cfg.seed
        )
        rel_test = self.cfg.test_size / (self.cfg.val_size + self.cfg.test_size)
        val_idx, test_idx = train_test_split(
            temp_idx, test_size=rel_test, stratify=self.families[temp_idx], random_state=self.cfg.seed
        )
        # Keep the randomized split order. The source CSV is grouped by Attack_type,
        # so sorting indices would reconstruct label blocks and create artificial temporal context.
        self.split = SplitData(
            train_idx, val_idx, test_idx,
            self.y[train_idx], self.y[val_idx], self.y[test_idx],
            self.families[train_idx], self.families[val_idx], self.families[test_idx]
        )
        return self.split

    def fit_transform_views(self):
        if self.split is None:
            self.make_split()
        views = {"train": {}, "val": {}, "test": {}}
        for name in AGENT_FEATURES:
            pp = AgentPreprocessor(name, self.cfg)
            pp.fit(self.df.iloc[self.split.train_idx], self.split.y_train)
            self.preprocessors[name] = pp
            views["train"][name] = pp.transform(self.df.iloc[self.split.train_idx])
            views["val"][name] = pp.transform(self.df.iloc[self.split.val_idx])
            views["test"][name] = pp.transform(self.df.iloc[self.split.test_idx])
        return views

    def preprocessing_summary(self) -> pd.DataFrame:
        rows = []
        for name, pp in self.preprocessors.items():
            rows.append({
                "agent": name,
                "raw_features": len(AGENT_FEATURES[name]),
                "numeric_kept": len(pp.keep_numeric),
                "log1p_features": len(pp.log_cols),
                "encoded_output_dim": len(pp.feature_names_out_),
            })
        return pd.DataFrame(rows)
