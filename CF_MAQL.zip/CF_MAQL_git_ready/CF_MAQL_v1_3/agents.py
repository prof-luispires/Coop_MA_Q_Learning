from __future__ import annotations
import numpy as np

class LinearQAgent:
    def __init__(self, input_dim: int, n_actions: int = 4, alpha: float = 1e-3,
                 gamma: float = 0.3, seed: int = 0, td_clip: float = 10.0,
                 weight_clip: float = 20.0):
        self.input_dim = input_dim
        self.n_actions = n_actions
        self.alpha = alpha
        self.gamma = gamma
        self.td_clip = td_clip
        self.weight_clip = weight_clip
        self.rng = np.random.default_rng(seed)
        # +1 for explicit bias.
        self.weights = np.zeros((n_actions, input_dim + 1), dtype=np.float64)

    def _phi(self, state: np.ndarray) -> np.ndarray:
        return np.concatenate(([1.0], np.asarray(state, dtype=np.float64)))

    def q_values(self, state: np.ndarray) -> np.ndarray:
        return self.weights @ self._phi(state)

    def action(self, state: np.ndarray, epsilon: float = 0.0) -> int:
        if self.rng.random() < epsilon:
            return int(self.rng.integers(self.n_actions))
        q = self.q_values(state)
        mx = np.flatnonzero(q == q.max())
        return int(self.rng.choice(mx))

    def confidence(self, state: np.ndarray) -> float:
        q = np.sort(self.q_values(state))
        margin = max(0.0, float(q[-1] - q[-2]))
        return float(np.tanh(margin))

    def update(self, state: np.ndarray, action: int, reward: float,
               next_state: np.ndarray | None, terminal: bool = False) -> float:
        phi = self._phi(state)
        q_sa = float(self.weights[action] @ phi)
        target = float(reward)
        if not terminal and next_state is not None:
            target += self.gamma * float(np.max(self.q_values(next_state)))
        td = float(np.clip(target - q_sa, -self.td_clip, self.td_clip))
        self.weights[action] += self.alpha * td * phi
        np.clip(self.weights, -self.weight_clip, self.weight_clip, out=self.weights)
        return td
