from dataclasses import dataclass, field
from typing import Dict, Tuple

ACTIONS = ("ALLOW", "MONITOR", "INSPECT", "BLOCK")
ACTION_TO_BINARY = {0: 0, 1: 0, 2: 1, 3: 1}
BENIGN_CLASSES = {"Thing_Speak", "MQTT_Publish", "Wipro_bulb"}

AGENT_FEATURES = {
    "flow": [
        "flow_duration", "fwd_pkts_tot", "bwd_pkts_tot",
        "fwd_data_pkts_tot", "bwd_data_pkts_tot",
        "fwd_pkts_per_sec", "bwd_pkts_per_sec",
        "flow_pkts_per_sec", "down_up_ratio",
    ],
    "temporal": [
        "fwd_iat.min", "fwd_iat.max", "fwd_iat.tot", "fwd_iat.avg", "fwd_iat.std",
        "bwd_iat.min", "bwd_iat.max", "bwd_iat.tot", "bwd_iat.avg", "bwd_iat.std",
        "flow_iat.min", "flow_iat.max", "flow_iat.tot", "flow_iat.avg", "flow_iat.std",
        "active.min", "active.max", "active.tot", "active.avg", "active.std",
        "idle.min", "idle.max", "idle.tot", "idle.avg", "idle.std",
    ],
    "protocol": [
        "id.orig_p", "id.resp_p", "proto", "service",
        "fwd_header_size_tot", "fwd_header_size_min", "fwd_header_size_max",
        "bwd_header_size_tot", "bwd_header_size_min", "bwd_header_size_max",
        "flow_FIN_flag_count", "flow_SYN_flag_count", "flow_RST_flag_count",
        "fwd_PSH_flag_count", "bwd_PSH_flag_count", "flow_ACK_flag_count",
        "fwd_URG_flag_count", "flow_CWR_flag_count", "flow_ECE_flag_count",
        "fwd_init_window_size", "bwd_init_window_size", "fwd_last_window_size",
    ],
    "payload": [
        "fwd_pkts_payload.min", "fwd_pkts_payload.max", "fwd_pkts_payload.tot",
        "fwd_pkts_payload.avg", "fwd_pkts_payload.std",
        "bwd_pkts_payload.min", "bwd_pkts_payload.max", "bwd_pkts_payload.tot",
        "bwd_pkts_payload.avg", "bwd_pkts_payload.std",
        "flow_pkts_payload.min", "flow_pkts_payload.max", "flow_pkts_payload.tot",
        "flow_pkts_payload.avg", "flow_pkts_payload.std",
        "payload_bytes_per_second",
        "fwd_subflow_pkts", "bwd_subflow_pkts", "fwd_subflow_bytes", "bwd_subflow_bytes",
        "fwd_bulk_bytes", "bwd_bulk_bytes", "fwd_bulk_packets", "bwd_bulk_packets",
        "fwd_bulk_rate", "bwd_bulk_rate",
    ],
}

@dataclass
class FrameworkConfig:
    seed: int = 11
    train_size: float = 0.70
    val_size: float = 0.15
    test_size: float = 0.15
    selected_features: bool = False
    corr_threshold: float = 0.95
    skew_threshold: float = 2.0
    alpha: float = 1e-3
    gamma: float = 0.0  # leakage-safe contextual benchmark: no justified temporal transition model
    lambda_local: float = 0.50
    epsilon_start: float = 1.0
    epsilon_min: float = 0.05
    epsilon_decay: float = 0.92
    episodes: int = 8
    td_clip: float = 10.0
    weight_clip: float = 20.0
    # v1.2 additions
    confidence_temperature: float = 0.25
    interaction_eta: float = 0.50
    interaction_q_scale: float = 4.0
    class_weight_cap: float = 5.0
    class_weight_power: float = 0.25  # conservative inverse-frequency power weighting
    reward_matrix: Dict[int, Tuple[float, float]] = field(default_factory=lambda: {
        0: (2.0, -6.0),  # ALLOW: benign, attack
        1: (1.0, -2.0),  # MONITOR
        2: (-1.0, 2.0),  # INSPECT
        3: (-4.0, 4.0),  # BLOCK
    })
