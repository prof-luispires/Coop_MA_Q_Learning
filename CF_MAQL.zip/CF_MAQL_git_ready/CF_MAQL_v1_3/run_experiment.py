from __future__ import annotations
import argparse, json, time
from pathlib import Path
import numpy as np
import pandas as pd
from .config import FrameworkConfig
from .data import RTIoT2022DataModule
from .framework import CFMAQL


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--out", default="results")
    ap.add_argument("--selected", action="store_true")
    ap.add_argument("--episodes", type=int, default=8)
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--max-train", type=int, default=None, help="Optional smoke-test cap")
    args = ap.parse_args()

    cfg = FrameworkConfig(seed=args.seed, selected_features=args.selected, episodes=args.episodes)
    out_dir = Path(args.out); out_dir.mkdir(parents=True, exist_ok=True)

    dm = RTIoT2022DataModule(args.csv, cfg)
    split = dm.make_split()
    views = dm.fit_transform_views()
    dm.preprocessing_summary().to_csv(out_dir / "preprocessing_summary.csv", index=False)

    if args.max_train:
        n = min(args.max_train, len(split.y_train))
        train_views = {k: v[:n] for k, v in views["train"].items()}
        y_train = split.y_train[:n]
    else:
        train_views = views["train"]
        y_train = split.y_train

    dims = {k: v.shape[1] for k, v in train_views.items()}
    model = CFMAQL(dims, cfg, fusion="confidence", cooperative_reward=True)
    t0 = time.perf_counter()
    history = model.fit(train_views, y_train)
    train_time = time.perf_counter() - t0

    val = model.evaluate(views["val"], split.y_val, split.family_val)
    test = model.evaluate(views["test"], split.y_test, split.family_test)
    payload = {
        "config": vars(cfg),
        "view_dims": dims,
        "train_seconds": train_time,
        "validation": val,
        "test": test,
    }
    # Convert reward matrix keys to strings safely via default serializer.
    with open(out_dir / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, default=str)
    pd.DataFrame(history).to_csv(out_dir / "training_history.csv", index=False)
    np.savez(out_dir / "model_weights.npz", **{k: a.weights for k, a in model.agents.items()})
    print(json.dumps({"view_dims": dims, "train_seconds": train_time, "test": test}, indent=2, default=str))

if __name__ == "__main__":
    main()
