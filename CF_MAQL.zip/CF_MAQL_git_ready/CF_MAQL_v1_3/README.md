# CF-MAQL v1.3 — Validation-Calibrated Security Operating Point

CF-MAQL v1.3 freezes the v1.2 architecture and changes only the final binary operating point of the learned interaction-aware coordinator.

## Frozen v1.2 core

- four partial-observation agents: Flow, Temporal, Protocol, Payload;
- linear local Q-functions;
- learned interaction-aware coordinator using 4 bounded local Q-values, 6 pairwise Q interactions, and 4 confidence weights per candidate action;
- gamma = 0 (offline contextual decision setting);
- 70/15/15 outer split stratified by Attack_type;
- within outer train: 60% local-agent learning + disjoint 10% coordinator learning;
- preprocessing fitted only on the outer training partition;
- coordinator hyperparameters frozen at alpha=0.01, 12 coordinator episodes, confidence temperature=0.50.

## v1.3 change

The coordinator produces an attack score from the margin between the strongest attack-side and benign-side coordinator Q-values. v1.2 used the natural operating point score >= 0.5. v1.3 calibrates a single global threshold using validation data only.

The threshold is selected across seeds 11, 22, 33, 44 and 55 by:

1. requiring mean validation recall >= 0.995;
2. maximizing mean validation MCC;
3. tie-breaking by balanced accuracy, F1, and then lower FPR.

No test observations are used for threshold selection.

Run:

```bash
python -m CF_MAQL_v1_3.benchmark_v13 --csv /path/to/RT_IOT2022.csv --out /path/to/results
```

## Frozen v1.3 operating point (5-seed validation)

The validation-only calibration selected a global attack-score threshold of **0.5375**. On the untouched test partitions, relative to the v1.2 threshold of 0.5, this yielded a small but consistent operating-point improvement in mean FPR and balanced accuracy while preserving attack recall above 0.998 on average.

The threshold calibration does **not** change PR-AUC or ROC-AUC because the underlying continuous coordinator score is unchanged.
