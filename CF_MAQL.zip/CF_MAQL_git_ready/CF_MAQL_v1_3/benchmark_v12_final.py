from __future__ import annotations
import argparse, json, time
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from .config import FrameworkConfig
from .data import RTIoT2022DataModule
from .benchmark_v12 import (pad_views, train_multi, train_single, predict_multi, predict_single,
                            local_q_tensor, train_coordinator, predict_coordinator,
                            metrics, famrec)

# Final v1.2 protocol:
# - Full feature views only (v1.1 showed Selected did not improve core metrics).
# - 70/15/15 family-stratified outer split remains unchanged.
# - The 70% training partition is internally split 60%/10% (agent-train/meta-coordinator-train).
# - Preprocessing is fit only on the outer 70% training partition.
# - Coordinator hyperparameters are selected using the untouched 15% validation partition,
#   aggregated across the five seeds; test data are not used for tuning.
# - The v1.2 coordinator consumes only local Q outputs/confidences, never raw features from other agents.

AGENTS=['flow','temporal','protocol','payload']

def inner_split_positions(families, seed):
    pos=np.arange(len(families))
    p_agent,p_coord=train_test_split(pos,test_size=(1.0/7.0),stratify=families,random_state=seed+101)
    return p_agent,p_coord

def subset_views(views, pos):
    return {k:v[pos] for k,v in views.items()}

def train_local_cf(cfg, split, views, p_agent, seed, episodes):
    vtr=subset_views(views['train'],p_agent); Xtr,dims,names=pad_views(vtr)
    y=split.y_train[p_agent]
    W,hr,ht=train_multi(Xtr,dims,y,np.ones(len(y),dtype=np.float64),episodes,cfg.alpha,cfg.lambda_local,
                        cfg.epsilon_start,cfg.epsilon_min,cfg.epsilon_decay,cfg.td_clip,cfg.weight_clip,
                        1,True,cfg.confidence_temperature,0.0,cfg.interaction_q_scale,seed)
    return W,dims,hr,ht

def evaluate_simple_config(name,cfg,split,views,kind,fmode,coop,seed,episodes):
    t0=time.perf_counter()
    if kind=='single':
        Xtr=np.hstack([views['train'][k] for k in AGENTS]).astype(np.float32)
        Xte=np.hstack([views['test'][k] for k in AGENTS]).astype(np.float32)
        W,hr,ht=train_single(Xtr,split.y_train,episodes,cfg.alpha,cfg.epsilon_start,cfg.epsilon_min,cfg.epsilon_decay,cfg.td_clip,cfg.weight_clip,seed)
        yp,score,actions=predict_single(Xte,W); wmean=[np.nan]*4
    else:
        Xtr,dims,names=pad_views(views['train']); Xte,_,_=pad_views(views['test'])
        W,hr,ht=train_multi(Xtr,dims,split.y_train,np.ones(len(split.y_train),dtype=np.float64),episodes,cfg.alpha,cfg.lambda_local,
                            cfg.epsilon_start,cfg.epsilon_min,cfg.epsilon_decay,cfg.td_clip,cfg.weight_clip,
                            fmode,coop,cfg.confidence_temperature,0.0,cfg.interaction_q_scale,seed)
        yp,score,wts,actions=predict_multi(Xte,dims,W,fmode,cfg.confidence_temperature,0.0,cfg.interaction_q_scale); wmean=wts.mean(axis=0)
    m=metrics(split.y_test,yp,score); m.update(configuration=name,seed=seed,train_seconds=time.perf_counter()-t0,episodes=episodes)
    for i,a in enumerate(AGENTS): m[f'weight_{a}']=float(wmean[i]) if kind!='single' else np.nan
    return m,famrec(split.y_test,yp,split.family_test),hr,ht

def prepare_seed(csv,seed,episodes,temp=0.25):
    cfg=FrameworkConfig(seed=seed,selected_features=False,episodes=episodes,gamma=0.0,confidence_temperature=temp)
    dm=RTIoT2022DataModule(csv,cfg); split=dm.make_split(); views=dm.fit_transform_views()
    p_agent,p_coord=inner_split_positions(split.family_train,seed)
    W,dims,hr,ht=train_local_cf(cfg,split,views,p_agent,seed,episodes)
    Xcoord,_,_=pad_views(subset_views(views['train'],p_coord)); Xval,_,_=pad_views(views['val']); Xtest,_,_=pad_views(views['test'])
    qcoord=local_q_tensor(Xcoord,dims,W); qval=local_q_tensor(Xval,dims,W); qtest=local_q_tensor(Xtest,dims,W)
    return cfg,dm,split,views,p_agent,p_coord,W,dims,qcoord,qval,qtest,hr,ht

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--csv',required=True); ap.add_argument('--out',required=True); ap.add_argument('--episodes',type=int,default=8); ap.add_argument('--seeds',default='11,22,33,44,55'); args=ap.parse_args()
    seeds=[int(x) for x in args.seeds.split(',') if x.strip()]; out=Path(args.out); out.mkdir(parents=True,exist_ok=True)

    prepared={}
    for seed in seeds:
        print('Preparing v1.2 seed',seed,flush=True); prepared[seed]=prepare_seed(args.csv,seed,args.episodes)

    # Hyperparameter selection on validation only. Keep the grid intentionally small.
    grid=[]
    for alpha in [0.001,0.003,0.01]:
        for ce in [8,12]:
            for temp in [0.15,0.25,0.50]: grid.append((alpha,ce,temp))
    tune=[]
    for alpha,ce,temp in grid:
        for seed in seeds:
            cfg,dm,sp,views,pa,pc,W,dims,qc,qv,qt,hr,ht=prepared[seed]
            Wc,chr=train_coordinator(qc,sp.y_train[pc],np.ones(len(pc),dtype=np.float64),ce,alpha,1.0,0.05,0.90,cfg.td_clip,cfg.weight_clip,cfg.interaction_q_scale,temp,seed)
            yp,sc,ac=predict_coordinator(qv,Wc,cfg.interaction_q_scale,temp); mm=metrics(sp.y_val,yp,sc)
            tune.append({'alpha':alpha,'coord_episodes':ce,'temperature':temp,'seed':seed,**{k:mm[k] for k in ['f1','mcc','balanced_accuracy','pr_auc','fpr','fnr']}})
    tdf=pd.DataFrame(tune); tdf.to_csv(out/'hyperparameter_validation.csv',index=False)
    ts=tdf.groupby(['alpha','coord_episodes','temperature'],as_index=False).agg(mcc_mean=('mcc','mean'),mcc_std=('mcc','std'),ba_mean=('balanced_accuracy','mean'),f1_mean=('f1','mean'),pr_auc_mean=('pr_auc','mean'))
    ts=ts.sort_values(['mcc_mean','ba_mean','f1_mean'],ascending=False); ts.to_csv(out/'hyperparameter_validation_summary.csv',index=False)
    best=ts.iloc[0]; ba=float(best.alpha); be=int(best.coord_episodes); bt=float(best.temperature)
    (out/'selected_hyperparameters.json').write_text(json.dumps({'coord_alpha':ba,'coord_episodes':be,'confidence_temperature':bt,'selection':'max mean validation MCC; tie-break balanced accuracy then F1','seeds':seeds},indent=2))
    print('Selected coordinator',ba,be,bt,'val MCC',best.mcc_mean,flush=True)

    rows=[]; famrows=[]; histories=[]
    for seed in seeds:
        cfg,dm,sp,views,pa,pc,W,dims,qc,qv,qt,hr,ht=prepared[seed]
        # frozen conventional/reference configurations use outer 70% training, matching v1.1
        for name,kind,fmode,coop in [('Single-Q','single',0,False),('Independent-Q','multi',0,False),('MAQL-Uniform','multi',0,True),('CF-v1.1-Ref','multi',1,True)]:
            m,fr,h1,h2=evaluate_simple_config(name,cfg,sp,views,kind,fmode,coop,seed,args.episodes); rows.append(m)
            for f,r in fr.items(): famrows.append({'configuration':name,'seed':seed,'family':f,'recall':r})
            for ep in range(args.episodes): histories.append({'configuration':name,'seed':seed,'episode':ep+1,'mean_global_reward':float(h1[ep]),'mean_abs_td':float(h2[ep])})
            print(name,seed,'F1',round(m['f1'],4),'MCC',round(m['mcc'],4),'BA',round(m['balanced_accuracy'],4),flush=True)

        # v1.2: local agents trained on 60%, learned interaction coordinator trained on disjoint 10%, tuned on 15% val.
        t0=time.perf_counter(); Wc,chr=train_coordinator(qc,sp.y_train[pc],np.ones(len(pc),dtype=np.float64),be,ba,1.0,0.05,0.90,cfg.td_clip,cfg.weight_clip,cfg.interaction_q_scale,bt,seed)
        yp,score,actions=predict_coordinator(qt,Wc,cfg.interaction_q_scale,bt); m=metrics(sp.y_test,yp,score)
        m.update(configuration='CF-MAQL-v1.2',seed=seed,train_seconds=time.perf_counter()-t0,episodes=args.episodes,coord_alpha=ba,coord_episodes=be,temperature=bt,agent_train_fraction=0.60,coordinator_train_fraction=0.10)
        for a in AGENTS: m[f'weight_{a}']=np.nan
        rows.append(m); fr=famrec(sp.y_test,yp,sp.family_test)
        for f,r in fr.items(): famrows.append({'configuration':'CF-MAQL-v1.2','seed':seed,'family':f,'recall':r})
        for ep in range(len(chr)): histories.append({'configuration':'CF-MAQL-v1.2-Coordinator','seed':seed,'episode':ep+1,'mean_global_reward':float(chr[ep]),'mean_abs_td':np.nan})
        print('CF-MAQL-v1.2',seed,'F1',round(m['f1'],4),'MCC',round(m['mcc'],4),'BA',round(m['balanced_accuracy'],4),flush=True)

    rdf=pd.DataFrame(rows); rdf.to_csv(out/'per_run_metrics.csv',index=False); pd.DataFrame(famrows).to_csv(out/'family_recall.csv',index=False); pd.DataFrame(histories).to_csv(out/'training_history_all.csv',index=False)
    cols=['precision','recall','f1','mcc','balanced_accuracy','pr_auc','roc_auc','fpr','fnr','train_seconds']
    summ=[]
    for c,g in rdf.groupby('configuration',sort=False):
        rr={'configuration':c}
        for col in cols: rr[col+'_mean']=g[col].mean(); rr[col+'_std']=g[col].std(ddof=1)
        summ.append(rr)
    pd.DataFrame(summ).to_csv(out/'summary_metrics.csv',index=False)
    cf=rdf[rdf.configuration=='CF-MAQL-v1.2'].set_index('seed'); comps=[]
    for c in ['Single-Q','Independent-Q','MAQL-Uniform','CF-v1.1-Ref']:
        gg=rdf[rdf.configuration==c].set_index('seed')
        for metric in ['f1','mcc','pr_auc','balanced_accuracy','recall','fpr','fnr']:
            d=cf[metric]-gg[metric]
            comps.append({'comparison':f'CF-MAQL-v1.2 - {c}','metric':metric,'mean_difference':d.mean(),'std_difference':d.std(ddof=1),'wins':int((d>0).sum()),'ties':int((d==0).sum()),'losses':int((d<0).sum())})
    pd.DataFrame(comps).to_csv(out/'paired_differences.csv',index=False)
    fdf=pd.DataFrame(famrows); fsum=fdf.groupby(['configuration','family'],as_index=False).agg(recall_mean=('recall','mean'),recall_std=('recall','std')); fsum.to_csv(out/'family_recall_summary.csv',index=False)
    (out/'benchmark_notes.txt').write_text('CF-MAQL v1.2 final controlled benchmark. The original class-aware reward and fixed interaction pilot were retained as optional code paths but were not promoted to the default because validation/pilot behaviour degraded global discrimination. The final v1.2 innovation is a learned interaction-aware coordinator operating only on local agent Q outputs and confidence features. Outer split: 70/15/15 stratified by Attack_type. Within outer train: 60% local-agent training + disjoint 10% coordinator training. Preprocessing fit only on outer train. Coordinator hyperparameters selected using validation aggregated across seeds. Test data are untouched until final evaluation. gamma=0 because RT-IoT2022 provides no defensible action-dependent temporal transition model.\n')

if __name__=='__main__': main()
