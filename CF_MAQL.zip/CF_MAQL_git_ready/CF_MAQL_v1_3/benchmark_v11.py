from __future__ import annotations
import json, time, argparse
from pathlib import Path
import numpy as np
import pandas as pd
from numba import njit
from sklearn.metrics import precision_score, recall_score, f1_score, matthews_corrcoef, balanced_accuracy_score, average_precision_score, roc_auc_score, confusion_matrix
from .config import FrameworkConfig
from .data import RTIoT2022DataModule

# v1.1 benchmark deliberately disables the historical shared context and uses gamma=0.
# RT-IoT2022 contains no timestamp/session ordering and its source CSV is class-blocked.
# This avoids exploiting artificial ordering while testing the cooperative architecture itself.

@njit(cache=True)
def _qvals(w, x, d):
    # w: 4 x (maxd+1), x padded maxd
    out = np.empty(4, dtype=np.float64)
    for a in range(4):
        v = w[a, 0]
        for j in range(d):
            v += w[a, j+1] * x[j]
        out[a] = v
    return out

@njit(cache=True)
def _argmax4(q):
    m = 0
    if q[1] > q[m]: m = 1
    if q[2] > q[m]: m = 2
    if q[3] > q[m]: m = 3
    return m

@njit(cache=True)
def _confidence(q):
    # largest minus second largest
    first = -1e300; second = -1e300
    for i in range(4):
        v = q[i]
        if v > first:
            second = first; first = v
        elif v > second:
            second = v
    m = first-second
    if m < 0: m = 0.0
    return np.tanh(m)

@njit(cache=True)
def train_multi(X, dims, y, episodes, alpha, lambda_local, eps_start, eps_min, eps_decay, td_clip, weight_clip, fusion_conf, cooperative, seed):
    # X n x agents x maxd
    np.random.seed(seed)
    n, na, maxd = X.shape
    W = np.zeros((na,4,maxd+1), dtype=np.float64)
    hist_reward = np.empty(episodes, dtype=np.float64)
    hist_td = np.empty(episodes, dtype=np.float64)
    eps = eps_start
    for ep in range(episodes):
        # shuffle observations each episode; no temporal semantics assumed
        order = np.random.permutation(n)
        sum_r=0.0; sum_td=0.0; cnt_td=0
        for kk in range(n):
            t=order[kk]
            q_all=np.empty((na,4),dtype=np.float64)
            conf=np.empty(na,dtype=np.float64)
            local_actions=np.empty(na,dtype=np.int64)
            for i in range(na):
                q=_qvals(W[i],X[t,i],dims[i]); q_all[i]=q; conf[i]=_confidence(q)
                if np.random.random() < eps:
                    local_actions[i]=np.random.randint(0,4)
                else:
                    local_actions[i]=_argmax4(q)
            # fusion only determines global action/reward
            qg=np.zeros(4,dtype=np.float64)
            if fusion_conf:
                s=0.0
                for i in range(na): s += conf[i]
                if s <= 1e-12:
                    for i in range(na):
                        for a in range(4): qg[a]+=q_all[i,a]/na
                else:
                    for i in range(na):
                        wi=conf[i]/s
                        for a in range(4): qg[a]+=wi*q_all[i,a]
            else:
                for i in range(na):
                    for a in range(4): qg[a]+=q_all[i,a]/na
            if np.random.random() < eps:
                ga=np.random.randint(0,4)
            else:
                ga=_argmax4(qg)
            yy=y[t]
            # reward matrix inline: action x [benign, attack]
            if yy==0:
                gr = 2.0 if ga==0 else (1.0 if ga==1 else (-1.0 if ga==2 else -4.0))
            else:
                gr = -6.0 if ga==0 else (-2.0 if ga==1 else (2.0 if ga==2 else 4.0))
            sum_r += gr
            for i in range(na):
                a=local_actions[i]
                if yy==0:
                    lr=2.0 if a==0 else (1.0 if a==1 else (-1.0 if a==2 else -4.0))
                else:
                    lr=-6.0 if a==0 else (-2.0 if a==1 else (2.0 if a==2 else 4.0))
                r=lambda_local*lr+(1-lambda_local)*gr if cooperative else lr
                td=r-q_all[i,a]  # gamma=0 contextual update
                if td>td_clip: td=td_clip
                elif td < -td_clip: td=-td_clip
                W[i,a,0]+=alpha*td
                d=dims[i]
                for j in range(d):
                    W[i,a,j+1]+=alpha*td*X[t,i,j]
                # clip updated row only
                for j in range(d+1):
                    if W[i,a,j]>weight_clip: W[i,a,j]=weight_clip
                    elif W[i,a,j]<-weight_clip: W[i,a,j]=-weight_clip
                sum_td += abs(td); cnt_td += 1
        hist_reward[ep]=sum_r/n
        hist_td[ep]=sum_td/cnt_td
        eps=max(eps_min,eps*eps_decay)
    return W,hist_reward,hist_td

@njit(cache=True)
def train_single(X, y, episodes, alpha, eps_start, eps_min, eps_decay, td_clip, weight_clip, seed):
    np.random.seed(seed)
    n,d=X.shape
    W=np.zeros((4,d+1),dtype=np.float64)
    hr=np.empty(episodes,dtype=np.float64); ht=np.empty(episodes,dtype=np.float64)
    eps=eps_start
    for ep in range(episodes):
        order=np.random.permutation(n); sr=0.0; st=0.0
        for kk in range(n):
            t=order[kk]
            q=np.empty(4,dtype=np.float64)
            for a in range(4):
                v=W[a,0]
                for j in range(d): v += W[a,j+1]*X[t,j]
                q[a]=v
            a=np.random.randint(0,4) if np.random.random()<eps else _argmax4(q)
            yy=y[t]
            if yy==0: r=2.0 if a==0 else (1.0 if a==1 else (-1.0 if a==2 else -4.0))
            else: r=-6.0 if a==0 else (-2.0 if a==1 else (2.0 if a==2 else 4.0))
            td=r-q[a]
            if td>td_clip: td=td_clip
            elif td < -td_clip: td=-td_clip
            W[a,0]+=alpha*td
            for j in range(d): W[a,j+1]+=alpha*td*X[t,j]
            for j in range(d+1):
                if W[a,j]>weight_clip: W[a,j]=weight_clip
                elif W[a,j]<-weight_clip: W[a,j]=-weight_clip
            sr+=r; st+=abs(td)
        hr[ep]=sr/n; ht[ep]=st/n; eps=max(eps_min,eps*eps_decay)
    return W,hr,ht

@njit(cache=True)
def predict_multi(X,dims,W,fusion_conf):
    n,na,maxd=X.shape
    pred=np.empty(n,dtype=np.int8); score=np.empty(n,dtype=np.float64); weights=np.empty((n,na),dtype=np.float64); actions=np.empty(n,dtype=np.int8)
    for t in range(n):
        q_all=np.empty((na,4),dtype=np.float64); conf=np.empty(na,dtype=np.float64)
        for i in range(na):
            q=_qvals(W[i],X[t,i],dims[i]); q_all[i]=q; conf[i]=_confidence(q)
        qg=np.zeros(4,dtype=np.float64)
        if fusion_conf:
            s=0.0
            for i in range(na): s+=conf[i]
            if s<=1e-12:
                for i in range(na):
                    weights[t,i]=1.0/na
                    for a in range(4): qg[a]+=q_all[i,a]/na
            else:
                for i in range(na):
                    wi=conf[i]/s; weights[t,i]=wi
                    for a in range(4): qg[a]+=wi*q_all[i,a]
        else:
            for i in range(na):
                weights[t,i]=1.0/na
                for a in range(4): qg[a]+=q_all[i,a]/na
        a=_argmax4(qg); actions[t]=a; pred[t]=0 if a<2 else 1
        margin=max(qg[2],qg[3])-max(qg[0],qg[1])
        if margin>30: margin=30
        elif margin<-30: margin=-30
        score[t]=1.0/(1.0+np.exp(-margin))
    return pred,score,weights,actions

@njit(cache=True)
def predict_single(X,W):
    n,d=X.shape; pred=np.empty(n,dtype=np.int8); score=np.empty(n,dtype=np.float64); actions=np.empty(n,dtype=np.int8)
    for t in range(n):
        q=np.empty(4,dtype=np.float64)
        for a in range(4):
            v=W[a,0]
            for j in range(d): v+=W[a,j+1]*X[t,j]
            q[a]=v
        a=_argmax4(q); actions[t]=a; pred[t]=0 if a<2 else 1
        margin=max(q[2],q[3])-max(q[0],q[1])
        if margin>30: margin=30
        elif margin<-30: margin=-30
        score[t]=1.0/(1.0+np.exp(-margin))
    return pred,score,actions

def metrics(y,yp,score):
    tn,fp,fn,tp=confusion_matrix(y,yp,labels=[0,1]).ravel()
    return dict(precision=precision_score(y,yp,zero_division=0), recall=recall_score(y,yp,zero_division=0), f1=f1_score(y,yp,zero_division=0), mcc=matthews_corrcoef(y,yp), balanced_accuracy=balanced_accuracy_score(y,yp), pr_auc=average_precision_score(y,score), roc_auc=roc_auc_score(y,score), fpr=fp/(fp+tn), fnr=fn/(fn+tp),tp=int(tp),tn=int(tn),fp=int(fp),fn=int(fn))

def pad_views(views):
    names=list(views.keys()); dims=np.array([views[n].shape[1] for n in names],dtype=np.int64); maxd=int(dims.max()); n=len(next(iter(views.values())))
    X=np.zeros((n,len(names),maxd),dtype=np.float32)
    for i,name in enumerate(names): X[:,i,:dims[i]]=views[name]
    return X,dims,names

def famrec(y,yp,fams):
    out={}; fams=np.asarray(fams)
    for f in np.unique(fams):
        m=fams==f
        if y[m].sum()>0: out[str(f)]=float(np.mean(yp[m]==1))
    return out

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--csv',required=True); ap.add_argument('--out',required=True); ap.add_argument('--episodes',type=int,default=8); ap.add_argument('--seeds',default='11,22,33,44,55'); args=ap.parse_args()
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    seeds=[int(x) for x in args.seeds.split(',') if x.strip()]
    configs=[('Single-Q',False,'single',False,False),('Independent-Q',False,'multi',False,False),('MAQL-Uniform',False,'multi',False,True),('CF-MAQL-Full',False,'multi',True,True),('CF-MAQL-Selected',True,'multi',True,True)]
    rows=[]; famrows=[]; histories=[]; feature_rows=[]
    for seed in seeds:
        cache={}
        for selected in (False,True):
            cfg=FrameworkConfig(seed=seed,selected_features=selected,episodes=args.episodes,gamma=0.0)
            dm=RTIoT2022DataModule(args.csv,cfg); split=dm.make_split(); views=dm.fit_transform_views(); cache[selected]=(cfg,dm,split,views)
            for an,pp in dm.preprocessors.items():
                feature_rows.append({'seed':seed,'selected':selected,'agent':an,'numeric_kept':len(pp.keep_numeric),'log1p':len(pp.log_cols),'encoded_dim':len(pp.feature_names_out_),'features':'|'.join(pp.feature_names_out_)})
        for name,selected,kind,conf,coop in configs:
            cfg,dm,split,views=cache[selected]
            t0=time.perf_counter()
            if kind=='single':
                Xtr=np.hstack([views['train'][k] for k in ['flow','temporal','protocol','payload']]).astype(np.float32)
                Xte=np.hstack([views['test'][k] for k in ['flow','temporal','protocol','payload']]).astype(np.float32)
                W,hr,ht=train_single(Xtr,split.y_train,args.episodes,cfg.alpha,cfg.epsilon_start,cfg.epsilon_min,cfg.epsilon_decay,cfg.td_clip,cfg.weight_clip,seed)
                yp,score,actions=predict_single(Xte,W); wmean=[np.nan]*4
            else:
                Xtr,dims,names=pad_views(views['train']); Xte,_,_=pad_views(views['test'])
                W,hr,ht=train_multi(Xtr,dims,split.y_train,args.episodes,cfg.alpha,cfg.lambda_local,cfg.epsilon_start,cfg.epsilon_min,cfg.epsilon_decay,cfg.td_clip,cfg.weight_clip,conf,coop,seed)
                yp,score,wts,actions=predict_multi(Xte,dims,W,conf); wmean=wts.mean(axis=0)
            secs=time.perf_counter()-t0
            m=metrics(split.y_test,yp,score); m.update({'configuration':name,'seed':seed,'selected':selected,'train_seconds':secs,'episodes':args.episodes,'gamma':0.0})
            for i,an in enumerate(['flow','temporal','protocol','payload']): m[f'weight_{an}']=float(wmean[i]) if kind!='single' else np.nan
            rows.append(m)
            fr=famrec(split.y_test,yp,split.family_test)
            for f,r in fr.items(): famrows.append({'configuration':name,'seed':seed,'family':f,'recall':r})
            for ep in range(args.episodes): histories.append({'configuration':name,'seed':seed,'episode':ep+1,'mean_global_reward':float(hr[ep]),'mean_abs_td':float(ht[ep])})
            print(name,seed,'F1',round(m['f1'],4),'MCC',round(m['mcc'],4),'PR',round(m['pr_auc'],4),'s',round(secs,2),flush=True)
    rdf=pd.DataFrame(rows); rdf.to_csv(out/'per_run_metrics.csv',index=False)
    pd.DataFrame(famrows).to_csv(out/'family_recall.csv',index=False)
    pd.DataFrame(histories).to_csv(out/'training_history_all.csv',index=False)
    pd.DataFrame(feature_rows).to_csv(out/'feature_selection_by_seed.csv',index=False)
    metrics_cols=['precision','recall','f1','mcc','balanced_accuracy','pr_auc','roc_auc','fpr','fnr','train_seconds','weight_flow','weight_temporal','weight_protocol','weight_payload']
    summ=[]
    for c,g in rdf.groupby('configuration',sort=False):
        row={'configuration':c}
        for col in metrics_cols:
            row[col+'_mean']=g[col].mean(); row[col+'_std']=g[col].std(ddof=1)
        summ.append(row)
    pd.DataFrame(summ).to_csv(out/'summary_metrics.csv',index=False)
    # pairwise seed-matched differences vs CF-MAQL-Full for core metrics
    cf=rdf[rdf.configuration=='CF-MAQL-Full'].set_index('seed')
    comps=[]
    for c in ['Single-Q','Independent-Q','MAQL-Uniform','CF-MAQL-Selected']:
        gg=rdf[rdf.configuration==c].set_index('seed')
        for metric in ['f1','mcc','pr_auc','balanced_accuracy']:
            d=cf[metric]-gg[metric]
            comps.append({'comparison':f'CF-MAQL-Full - {c}','metric':metric,'mean_difference':d.mean(),'std_difference':d.std(ddof=1),'wins':int((d>0).sum()),'ties':int((d==0).sum()),'losses':int((d<0).sum())})
    pd.DataFrame(comps).to_csv(out/'paired_differences.csv',index=False)
    (out/'benchmark_notes.txt').write_text('CF-MAQL v1.1 controlled benchmark. Important correction: RT-IoT2022 CSV is grouped in 12 contiguous Attack_type blocks and contains no timestamp/session field. Therefore historical shared context was disabled, split was stratified by Attack_type and kept randomized, training order was shuffled each episode, and gamma was set to 0 for this first leakage-safe contextual benchmark.\n')

if __name__=='__main__': main()
