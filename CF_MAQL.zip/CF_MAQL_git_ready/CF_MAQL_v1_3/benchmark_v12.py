from __future__ import annotations
import time, argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from numba import njit
from sklearn.metrics import (precision_score, recall_score, f1_score, matthews_corrcoef,
                             balanced_accuracy_score, average_precision_score, roc_auc_score,
                             confusion_matrix)
from .config import FrameworkConfig, BENIGN_CLASSES
from .data import RTIoT2022DataModule

# CF-MAQL v1.2 keeps the leakage-safe contextual formulation of v1.1 (gamma=0, shuffled train order)
# and adds three controlled mechanisms:
# (1) training-only class-rarity-aware reward scaling for attack samples;
# (2) temperature-controlled softmax confidence fusion;
# (3) bounded pairwise interaction term in the coordinator.

@njit(cache=True)
def _qvals(w, x, d):
    out=np.empty(4,dtype=np.float64)
    for a in range(4):
        v=w[a,0]
        for j in range(d): v += w[a,j+1]*x[j]
        out[a]=v
    return out

@njit(cache=True)
def _argmax4(q):
    m=0
    if q[1]>q[m]: m=1
    if q[2]>q[m]: m=2
    if q[3]>q[m]: m=3
    return m

@njit(cache=True)
def _confidence_old(q):
    first=-1e300; second=-1e300
    for i in range(4):
        v=q[i]
        if v>first:
            second=first; first=v
        elif v>second:
            second=v
    m=first-second
    if m<0: m=0.0
    return np.tanh(m)

@njit(cache=True)
def _confidence_rel(q):
    # scale-invariant-ish top-two margin: [0,1)
    first=-1e300; second=-1e300
    for i in range(4):
        v=q[i]
        if v>first:
            second=first; first=v
        elif v>second:
            second=v
    margin=first-second
    if margin<0: margin=0.0
    den=abs(first)+abs(second)+1e-6
    return margin/den

@njit(cache=True)
def _softmax_weights(conf,temp,out):
    na=len(conf)
    if temp<=1e-8: temp=1e-8
    mx=conf[0]/temp
    for i in range(1,na):
        v=conf[i]/temp
        if v>mx: mx=v
    s=0.0
    for i in range(na):
        out[i]=np.exp(conf[i]/temp-mx); s+=out[i]
    if s<=1e-15:
        for i in range(na): out[i]=1.0/na
    else:
        for i in range(na): out[i]/=s

@njit(cache=True)
def _fuse(q_all, conf, fusion_mode, temp, eta, qscale, qg, weights):
    na=q_all.shape[0]
    for a in range(4): qg[a]=0.0
    if fusion_mode==0:  # uniform
        for i in range(na):
            weights[i]=1.0/na
            for a in range(4): qg[a]+=q_all[i,a]/na
    elif fusion_mode==1:  # v1.1 normalized margin
        s=0.0
        for i in range(na): s+=conf[i]
        if s<=1e-12:
            for i in range(na):
                weights[i]=1.0/na
                for a in range(4): qg[a]+=q_all[i,a]/na
        else:
            for i in range(na):
                wi=conf[i]/s; weights[i]=wi
                for a in range(4): qg[a]+=wi*q_all[i,a]
    else:  # v1.2 softmax confidence, optionally interaction-aware
        _softmax_weights(conf,temp,weights)
        for i in range(na):
            wi=weights[i]
            for a in range(4): qg[a]+=wi*q_all[i,a]
        if fusion_mode==3 and eta!=0.0:
            pairs=na*(na-1)//2
            for a in range(4):
                inter=0.0
                for i in range(na):
                    ui=np.tanh(q_all[i,a]/qscale)
                    for j in range(i+1,na):
                        uj=np.tanh(q_all[j,a]/qscale)
                        inter += ui*uj
                inter /= pairs
                qg[a] += eta*inter

@njit(cache=True)
def _reward(yy,a,w):
    if yy==0:
        return 2.0 if a==0 else (1.0 if a==1 else (-1.0 if a==2 else -4.0))
    base=-6.0 if a==0 else (-2.0 if a==1 else (2.0 if a==2 else 4.0))
    return base*w

@njit(cache=True)
def train_multi(X,dims,y,sample_w,episodes,alpha,lambda_local,eps_start,eps_min,eps_decay,
                td_clip,weight_clip,fusion_mode,cooperative,temp,eta,qscale,seed):
    np.random.seed(seed)
    n,na,maxd=X.shape
    W=np.zeros((na,4,maxd+1),dtype=np.float64)
    hr=np.empty(episodes,dtype=np.float64); ht=np.empty(episodes,dtype=np.float64)
    eps=eps_start
    for ep in range(episodes):
        order=np.random.permutation(n); sr=0.0; st=0.0; ct=0
        for kk in range(n):
            t=order[kk]
            q_all=np.empty((na,4),dtype=np.float64); conf=np.empty(na,dtype=np.float64); la=np.empty(na,dtype=np.int64)
            for i in range(na):
                q=_qvals(W[i],X[t,i],dims[i]); q_all[i]=q; conf[i]=_confidence_old(q) if fusion_mode==1 else _confidence_rel(q)
                la[i]=np.random.randint(0,4) if np.random.random()<eps else _argmax4(q)
            qg=np.zeros(4,dtype=np.float64); ws=np.empty(na,dtype=np.float64)
            _fuse(q_all,conf,fusion_mode,temp,eta,qscale,qg,ws)
            ga=np.random.randint(0,4) if np.random.random()<eps else _argmax4(qg)
            yy=y[t]; sw=sample_w[t]
            gr=_reward(yy,ga,sw); sr+=gr
            for i in range(na):
                a=la[i]; lr=_reward(yy,a,sw)
                r=lambda_local*lr+(1.0-lambda_local)*gr if cooperative else lr
                td=r-q_all[i,a]
                if td>td_clip: td=td_clip
                elif td<-td_clip: td=-td_clip
                W[i,a,0]+=alpha*td; d=dims[i]
                for j in range(d): W[i,a,j+1]+=alpha*td*X[t,i,j]
                for j in range(d+1):
                    if W[i,a,j]>weight_clip: W[i,a,j]=weight_clip
                    elif W[i,a,j]<-weight_clip: W[i,a,j]=-weight_clip
                st+=abs(td); ct+=1
        hr[ep]=sr/n; ht[ep]=st/ct; eps=max(eps_min,eps*eps_decay)
    return W,hr,ht

@njit(cache=True)
def train_single(X,y,episodes,alpha,eps_start,eps_min,eps_decay,td_clip,weight_clip,seed):
    np.random.seed(seed); n,d=X.shape; W=np.zeros((4,d+1),dtype=np.float64)
    hr=np.empty(episodes,dtype=np.float64); ht=np.empty(episodes,dtype=np.float64); eps=eps_start
    for ep in range(episodes):
        order=np.random.permutation(n); sr=0.0; st=0.0
        for kk in range(n):
            t=order[kk]; q=np.empty(4,dtype=np.float64)
            for a in range(4):
                v=W[a,0]
                for j in range(d): v+=W[a,j+1]*X[t,j]
                q[a]=v
            a=np.random.randint(0,4) if np.random.random()<eps else _argmax4(q)
            # Single-Q remains the frozen v1.1 reference: no rarity weighting.
            r=_reward(y[t],a,1.0); td=r-q[a]
            if td>td_clip: td=td_clip
            elif td<-td_clip: td=-td_clip
            W[a,0]+=alpha*td
            for j in range(d): W[a,j+1]+=alpha*td*X[t,j]
            for j in range(d+1):
                if W[a,j]>weight_clip: W[a,j]=weight_clip
                elif W[a,j]<-weight_clip: W[a,j]=-weight_clip
            sr+=r; st+=abs(td)
        hr[ep]=sr/n; ht[ep]=st/n; eps=max(eps_min,eps*eps_decay)
    return W,hr,ht

@njit(cache=True)
def predict_multi(X,dims,W,fusion_mode,temp,eta,qscale):
    n,na,maxd=X.shape
    pred=np.empty(n,dtype=np.int8); score=np.empty(n,dtype=np.float64); weights=np.empty((n,na),dtype=np.float64); actions=np.empty(n,dtype=np.int8)
    for t in range(n):
        q_all=np.empty((na,4),dtype=np.float64); conf=np.empty(na,dtype=np.float64)
        for i in range(na):
            q=_qvals(W[i],X[t,i],dims[i]); q_all[i]=q; conf[i]=_confidence_old(q) if fusion_mode==1 else _confidence_rel(q)
        qg=np.zeros(4,dtype=np.float64); ws=np.empty(na,dtype=np.float64)
        _fuse(q_all,conf,fusion_mode,temp,eta,qscale,qg,ws)
        for i in range(na): weights[t,i]=ws[i]
        a=_argmax4(qg); actions[t]=a; pred[t]=0 if a<2 else 1
        margin=max(qg[2],qg[3])-max(qg[0],qg[1])
        if margin>30: margin=30
        elif margin<-30: margin=-30
        score[t]=1.0/(1.0+np.exp(-margin))
    return pred,score,weights,actions

@njit(cache=True)
def predict_single(X,W):
    n,d=X.shape; pred=np.empty(n,dtype=np.int8); score=np.empty(n,dtype=np.float64); actions=np.empty(n,dtype=np.int8)
    for t in range(n):
        q=np.empty(4,dtype=np.float64)
        for a in range(4):
            v=W[a,0]
            for j in range(d): v+=W[a,j+1]*X[t,j]
            q[a]=v
        a=_argmax4(q); actions[t]=a; pred[t]=0 if a<2 else 1
        margin=max(q[2],q[3])-max(q[0],q[1]); margin=min(30.0,max(-30.0,margin)); score[t]=1.0/(1.0+np.exp(-margin))
    return pred,score,actions

def metrics(y,yp,score):
    tn,fp,fn,tp=confusion_matrix(y,yp,labels=[0,1]).ravel()
    return dict(precision=precision_score(y,yp,zero_division=0),recall=recall_score(y,yp,zero_division=0),f1=f1_score(y,yp,zero_division=0),
                mcc=matthews_corrcoef(y,yp),balanced_accuracy=balanced_accuracy_score(y,yp),pr_auc=average_precision_score(y,score),roc_auc=roc_auc_score(y,score),
                fpr=fp/(fp+tn),fnr=fn/(fn+tp),tp=int(tp),tn=int(tn),fp=int(fp),fn=int(fn))

def pad_views(views):
    names=list(views.keys()); dims=np.array([views[n].shape[1] for n in names],dtype=np.int64); maxd=int(dims.max()); n=len(next(iter(views.values())))
    X=np.zeros((n,len(names),maxd),dtype=np.float32)
    for i,name in enumerate(names): X[:,i,:dims[i]]=views[name]
    return X,dims,names

def family_weights(families_train,benign_classes,cap=5.0,power=0.25):
    # Training-only family reweighting. Raw inverse-frequency-power weights are bounded,
    # then normalized so the sample-weighted mean over attack observations is 1.0.
    # This changes emphasis among attack families without globally increasing the attack-vs-benign reward mass.
    s=pd.Series(families_train); counts=s.value_counts(); attack_counts=counts[~counts.index.isin(benign_classes)]
    maxc=float(attack_counts.max())
    raw={str(fam): float(min(cap,max(1.0,(maxc/float(c))**power))) for fam,c in attack_counts.items()}
    denom=sum(float(attack_counts.loc[f])*raw[str(f)] for f in attack_counts.index) / float(attack_counts.sum())
    return {str(f): float(raw[str(f)]/denom) for f in attack_counts.index}

def weight_vector(families,fmap):
    return np.array([fmap.get(str(f),1.0) for f in families],dtype=np.float64)

def famrec(y,yp,fams):
    out={}; fams=np.asarray(fams)
    for f in np.unique(fams):
        m=fams==f
        if y[m].sum()>0: out[str(f)]=float(np.mean(yp[m]==1))
    return out

def run_configuration(name,kind,fusion_mode,cooperative,classaware,cfg,dm,split,views,episodes,seed,evalset='test'):
    t0=time.perf_counter(); sample_map=family_weights(split.family_train,BENIGN_CLASSES,cfg.class_weight_cap,cfg.class_weight_power) if classaware else {}
    sw=weight_vector(split.family_train,sample_map) if classaware else np.ones(len(split.y_train),dtype=np.float64)
    if evalset=='test': yev=split.y_test; fev=split.family_test; vev=views['test']
    else: yev=split.y_val; fev=split.family_val; vev=views['val']
    if kind=='single':
        Xtr=np.hstack([views['train'][k] for k in ['flow','temporal','protocol','payload']]).astype(np.float32)
        Xev=np.hstack([vev[k] for k in ['flow','temporal','protocol','payload']]).astype(np.float32)
        W,hr,ht=train_single(Xtr,split.y_train,episodes,cfg.alpha,cfg.epsilon_start,cfg.epsilon_min,cfg.epsilon_decay,cfg.td_clip,cfg.weight_clip,seed)
        yp,score,actions=predict_single(Xev,W); wmean=[np.nan]*4
    else:
        Xtr,dims,names=pad_views(views['train']); Xev,_,_=pad_views(vev)
        W,hr,ht=train_multi(Xtr,dims,split.y_train,sw,episodes,cfg.alpha,cfg.lambda_local,cfg.epsilon_start,cfg.epsilon_min,cfg.epsilon_decay,cfg.td_clip,cfg.weight_clip,fusion_mode,cooperative,cfg.confidence_temperature,cfg.interaction_eta,cfg.interaction_q_scale,seed)
        yp,score,wts,actions=predict_multi(Xev,dims,W,fusion_mode,cfg.confidence_temperature,cfg.interaction_eta,cfg.interaction_q_scale); wmean=wts.mean(axis=0)
    secs=time.perf_counter()-t0; m=metrics(yev,yp,score)
    m.update({'configuration':name,'seed':seed,'train_seconds':secs,'episodes':episodes,'gamma':0.0,'temperature':cfg.confidence_temperature,'interaction_eta':cfg.interaction_eta,'classaware':classaware,'evalset':evalset})
    for i,an in enumerate(['flow','temporal','protocol','payload']): m[f'weight_{an}']=float(wmean[i]) if kind!='single' else np.nan
    return m,famrec(yev,yp,fev),hr,ht,sample_map

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--csv',required=True); ap.add_argument('--out',required=True); ap.add_argument('--episodes',type=int,default=8); ap.add_argument('--seeds',default='11,22,33,44,55'); ap.add_argument('--temperature',type=float,default=0.25); ap.add_argument('--eta',type=float,default=0.50); args=ap.parse_args()
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True); seeds=[int(x) for x in args.seeds.split(',') if x.strip()]
    # Controlled additive sequence: same full feature views, one mechanism at a time.
    configs=[
        ('Single-Q', 'single', 0, False, False),
        ('CF-v1.1-Ref','multi',1,True,False),
        ('CF-ClassAware','multi',1,True,True),
        ('CF-Class+Softmax','multi',2,True,True),
        ('CF-MAQL-v1.2','multi',3,True,True),
    ]
    rows=[]; famrows=[]; histories=[]; classrows=[]
    for seed in seeds:
        cfg=FrameworkConfig(seed=seed,selected_features=False,episodes=args.episodes,gamma=0.0,confidence_temperature=args.temperature,interaction_eta=args.eta)
        dm=RTIoT2022DataModule(args.csv,cfg); split=dm.make_split(); views=dm.fit_transform_views()
        for name,kind,fmode,coop,caware in configs:
            m,fr,hr,ht,cmap=run_configuration(name,kind,fmode,coop,caware,cfg,dm,split,views,args.episodes,seed,'test'); rows.append(m)
            for f,r in fr.items(): famrows.append({'configuration':name,'seed':seed,'family':f,'recall':r})
            for ep in range(args.episodes): histories.append({'configuration':name,'seed':seed,'episode':ep+1,'mean_global_reward':float(hr[ep]),'mean_abs_td':float(ht[ep])})
            if cmap:
                for f,w in cmap.items(): classrows.append({'seed':seed,'family':f,'train_reward_weight':w})
            print(name,seed,'F1',round(m['f1'],4),'MCC',round(m['mcc'],4),'BA',round(m['balanced_accuracy'],4),'PR',round(m['pr_auc'],4),'s',round(m['train_seconds'],2),flush=True)
    rdf=pd.DataFrame(rows); rdf.to_csv(out/'per_run_metrics.csv',index=False); pd.DataFrame(famrows).to_csv(out/'family_recall.csv',index=False); pd.DataFrame(histories).to_csv(out/'training_history_all.csv',index=False); pd.DataFrame(classrows).drop_duplicates().to_csv(out/'class_reward_weights.csv',index=False)
    metrics_cols=['precision','recall','f1','mcc','balanced_accuracy','pr_auc','roc_auc','fpr','fnr','train_seconds','weight_flow','weight_temporal','weight_protocol','weight_payload']
    summ=[]
    for c,g in rdf.groupby('configuration',sort=False):
        row={'configuration':c}
        for col in metrics_cols: row[col+'_mean']=g[col].mean(); row[col+'_std']=g[col].std(ddof=1)
        summ.append(row)
    pd.DataFrame(summ).to_csv(out/'summary_metrics.csv',index=False)
    full=rdf[rdf.configuration=='CF-MAQL-v1.2'].set_index('seed'); comps=[]
    for c in ['Single-Q','CF-v1.1-Ref','CF-ClassAware','CF-Class+Softmax']:
        gg=rdf[rdf.configuration==c].set_index('seed')
        for metric in ['f1','mcc','pr_auc','balanced_accuracy','recall','fpr','fnr']:
            d=full[metric]-gg[metric]
            comps.append({'comparison':f'CF-MAQL-v1.2 - {c}','metric':metric,'mean_difference':d.mean(),'std_difference':d.std(ddof=1),'wins':int((d>0).sum()),'ties':int((d==0).sum()),'losses':int((d<0).sum())})
    pd.DataFrame(comps).to_csv(out/'paired_differences.csv',index=False)
    fs=pd.DataFrame(famrows).groupby(['configuration','family'],as_index=False).recall.agg(['mean','std']).reset_index(); fs.to_csv(out/'family_recall_summary.csv',index=False)
    (out/'benchmark_notes.txt').write_text(f'CF-MAQL v1.2 benchmark. Leakage-safe contextual formulation retained (gamma=0, stratified Attack_type split, shuffled training order). New mechanisms: training-only sample-mass-normalized bounded inverse-frequency-power class rarity reward (cap={cfg.class_weight_cap}), relative Q-margin softmax confidence (temperature={args.temperature}), and bounded pairwise interaction coordinator (eta={args.eta}, qscale={cfg.interaction_q_scale}). Single-Q remains frozen v1.1 reference without class weighting.\n')

if __name__=='__main__': main()

@njit(cache=True)
def local_q_tensor(X,dims,W):
    n,na,maxd=X.shape
    out=np.empty((n,na,4),dtype=np.float64)
    for t in range(n):
        for i in range(na):
            out[t,i]=_qvals(W[i],X[t,i],dims[i])
    return out

@njit(cache=True)
def _coord_features(q_all_t,a,qscale,temp,out):
    # 4 bounded local Qs + 6 pairwise products + 4 softmax confidence weights = 14 features
    na=4
    u=np.empty(na,dtype=np.float64); conf=np.empty(na,dtype=np.float64); ws=np.empty(na,dtype=np.float64)
    for i in range(na):
        u[i]=np.tanh(q_all_t[i,a]/qscale)
        conf[i]=_confidence_rel(q_all_t[i])
    _softmax_weights(conf,temp,ws)
    k=0
    for i in range(na): out[k]=u[i]; k+=1
    for i in range(na):
        for j in range(i+1,na): out[k]=u[i]*u[j]; k+=1
    for i in range(na): out[k]=ws[i]; k+=1

@njit(cache=True)
def train_coordinator(qtensor,y,sample_w,episodes,alpha,eps_start,eps_min,eps_decay,td_clip,weight_clip,qscale,temp,seed):
    np.random.seed(seed+7919); n=qtensor.shape[0]; nf=14
    Wc=np.zeros((4,nf+1),dtype=np.float64); hr=np.empty(episodes,dtype=np.float64); eps=eps_start
    feat=np.empty(nf,dtype=np.float64)
    for ep in range(episodes):
        order=np.random.permutation(n); sr=0.0
        for kk in range(n):
            t=order[kk]; qc=np.empty(4,dtype=np.float64)
            for a in range(4):
                _coord_features(qtensor[t],a,qscale,temp,feat)
                v=Wc[a,0]
                for j in range(nf): v+=Wc[a,j+1]*feat[j]
                qc[a]=v
            a=np.random.randint(0,4) if np.random.random()<eps else _argmax4(qc)
            r=_reward(y[t],a,sample_w[t]); td=r-qc[a]
            if td>td_clip: td=td_clip
            elif td<-td_clip: td=-td_clip
            _coord_features(qtensor[t],a,qscale,temp,feat)
            Wc[a,0]+=alpha*td
            for j in range(nf): Wc[a,j+1]+=alpha*td*feat[j]
            for j in range(nf+1):
                if Wc[a,j]>weight_clip: Wc[a,j]=weight_clip
                elif Wc[a,j]<-weight_clip: Wc[a,j]=-weight_clip
            sr+=r
        hr[ep]=sr/n; eps=max(eps_min,eps*eps_decay)
    return Wc,hr

@njit(cache=True)
def predict_coordinator(qtensor,Wc,qscale,temp):
    n=qtensor.shape[0]; nf=14; pred=np.empty(n,dtype=np.int8); score=np.empty(n,dtype=np.float64); actions=np.empty(n,dtype=np.int8); feat=np.empty(nf,dtype=np.float64)
    for t in range(n):
        qc=np.empty(4,dtype=np.float64)
        for a in range(4):
            _coord_features(qtensor[t],a,qscale,temp,feat)
            v=Wc[a,0]
            for j in range(nf): v+=Wc[a,j+1]*feat[j]
            qc[a]=v
        a=_argmax4(qc); actions[t]=a; pred[t]=0 if a<2 else 1
        margin=max(qc[2],qc[3])-max(qc[0],qc[1]); margin=min(30.0,max(-30.0,margin)); score[t]=1.0/(1.0+np.exp(-margin))
    return pred,score,actions
