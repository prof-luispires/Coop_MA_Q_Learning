"""Generate the main manuscript Results figures from stored CF-MAQL CSV outputs."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
MASTER = ROOT / "results" / "consolidated" / "CF_MAQL_E1_E5_master_results.csv"
LOAFO = ROOT / "results" / "E3_LOAFO" / "unseen_recall_matrix.csv"
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)

df = pd.read_csv(MASTER)
rename = {
    "Single-Q": "Centralized Q",
    "Independent-Q": "Independent",
    "MAQL-Uniform": "Uniform fusion",
    "CF-MAQL v1.1": "Confidence fusion",
    "CF-MAQL v1.2": "Interaction-aware",
    "CF-MAQL v1.3": "CF-MAQL",
}

# Figure 5: E1 + E2
E1 = df[df.experiment.eq("E1")].copy(); E1["label"] = E1.method.replace(rename)
E2 = df[df.experiment.eq("E2")].copy()
order = ["Single-Q", "Independent-Q", "MAQL-Uniform", "CF-MAQL v1.1", "CF-MAQL v1.2", "CF-MAQL v1.3"]
E2 = E2.set_index("method").loc[order].reset_index(); E2["label"] = E2.method.replace(rename)
fig, ax = plt.subplots(2, 1, figsize=(10.5, 10))
x = np.arange(len(E1)); w = .36
for j,(m,s,l) in enumerate([("f1_mean","f1_std","F1-score"),("mcc_mean","mcc_std","MCC")]):
    ax[0].bar(x+(j-.5)*w, E1[m], w, yerr=E1[s], capsize=3, label=l)
ax[0].set_xticks(x); ax[0].set_xticklabels(E1.label, rotation=15, ha="right")
ax[0].set_ylabel("Score"); ax[0].set_ylim(.90,1.005); ax[0].set_title("(a) IID benchmark"); ax[0].grid(axis="y",alpha=.25); ax[0].legend(frameon=False,ncol=2)
x=np.arange(len(E2))
for m,s,l,marker in [("mcc_mean","mcc_std","MCC","o"),("fpr_mean","fpr_std","FPR","s")]:
    ax[1].plot(x,E2[m],marker=marker,linewidth=2,label=l)
    ax[1].fill_between(x,E2[m]-E2[s],E2[m]+E2[s],alpha=.12)
ax[1].set_xticks(x); ax[1].set_xticklabels(E2.label,rotation=15,ha="right")
ax[1].set_ylabel("Score / rate"); ax[1].set_ylim(0,1.02); ax[1].set_title("(b) Effect of coordination strategy"); ax[1].grid(axis="y",alpha=.25); ax[1].legend(frameon=False,ncol=2)
fig.tight_layout(h_pad=2); fig.savefig(FIG/"Figure_5_E1_E2_Performance_Coordination.png",dpi=600,bbox_inches="tight"); plt.close(fig)

# Figure 6: E3 LOAFO recall heatmap
m = pd.read_csv(LOAFO).set_index("holdout_family").rename(columns={"CF-MAQL-v1.3":"CF-MAQL"})
cols=["CF-MAQL","Random Forest","XGBoost","SVM-RBF","MLP"]
rows=["DoS-DDoS","Reconnaissance","ARP-Spoofing","Brute-Force"]
p=m.loc[rows,cols].T
fig,ax=plt.subplots(figsize=(9.2,5.6)); im=ax.imshow(p.values,aspect="auto",vmin=0,vmax=1)
ax.set_xticks(np.arange(len(rows))); ax.set_xticklabels(rows,rotation=15,ha="right")
ax.set_yticks(np.arange(len(cols))); ax.set_yticklabels(cols); ax.set_xlabel("Held-out attack family"); ax.set_ylabel("Method")
for i in range(p.shape[0]):
    for j in range(p.shape[1]): ax.text(j,i,f"{p.iloc[i,j]:.3f}",ha="center",va="center")
fig.colorbar(im,ax=ax,pad=.02,label="Unseen-family recall"); ax.set_title("LOAFO generalization to unseen attack families")
fig.tight_layout(); fig.savefig(FIG/"Figure_6_E3_LOAFO_Unseen_Recall_Heatmap.png",dpi=600,bbox_inches="tight"); plt.close(fig)

# Figure 7: E4 partial-view robustness
E4=df[df.experiment.eq("E4")].copy(); E4["method"]=E4.method.replace({"CF-MAQL v1.3":"CF-MAQL"})
methods=["CF-MAQL","Single-Q","XGBoost","Random Forest"]
drops=[f"Mean view dropout {q}%" for q in (25,50,75,100)]
loss=["100% loss: flow","100% loss: temporal","100% loss: protocol","100% loss: payload"]
fig,ax=plt.subplots(2,1,figsize=(9.5,9.5)); x=np.array([25,50,75,100])
for method in methods:
    s=E4[(E4.method.eq(method)) & E4.scenario.isin(drops)].copy(); s["pct"]=s.scenario.str.extract(r"(\d+)%")[0].astype(int); s=s.sort_values("pct")
    ax[0].errorbar(x,s.mcc_mean,yerr=s.mcc_std,marker="o",linewidth=1.8,capsize=3,label=method)
ax[0].set_title("(a) Progressive functional-view dropout"); ax[0].set_xlabel("Mean view dropout (%)"); ax[0].set_ylabel("MCC"); ax[0].set_xticks(x); ax[0].set_ylim(.45,1.02); ax[0].grid(axis="y",alpha=.25); ax[0].legend(frameon=False,ncol=2)
xx=np.arange(4); w=.19
for k,method in enumerate(methods):
    vals=[]; errs=[]
    for sc in loss:
        r=E4[(E4.method.eq(method)) & E4.scenario.eq(sc)].iloc[0]; vals.append(r.mcc_mean); errs.append(r.mcc_std)
    ax[1].bar(xx+(k-1.5)*w,vals,w,yerr=errs,capsize=2.5,label=method)
ax[1].set_title("(b) Complete loss of an individual functional view"); ax[1].set_xlabel("Unavailable functional view"); ax[1].set_ylabel("MCC"); ax[1].set_xticks(xx); ax[1].set_xticklabels(["Flow","Temporal","Protocol","Payload"]); ax[1].set_ylim(0,1.05); ax[1].grid(axis="y",alpha=.25); ax[1].legend(frameon=False,ncol=2)
fig.tight_layout(h_pad=2.2); fig.savefig(FIG/"Figure_7_E4_Partial_View_Robustness.png",dpi=600,bbox_inches="tight"); plt.close(fig)

# Figure 8: E5 structural ablation
E5=df[df.experiment.eq("E5")].copy(); base=float(E5[E5.method.eq("Full-CF-MAQL-v1.3")].mcc_mean.iloc[0])
wanted=[("No-Pairwise-Interactions","No pairwise\ninteractions"),("No-Confidence-Features","No confidence\nfeatures"),("No-Pairwise-No-Confidence","No pairwise /\nconfidence"),("No-Learned-Coordinator-CF-v1.1","No learned\ncoordinator"),("Uncalibrated-Threshold-0.5","Threshold\n0.5"),("Minus-Flow","Minus\nFlow"),("Minus-Temporal","Minus\nTemporal"),("Minus-Protocol","Minus\nProtocol"),("Minus-Payload","Minus\nPayload")]
labels=[]; delta=[]
for method,label in wanted:
    labels.append(label); delta.append(float(E5[E5.method.eq(method)].mcc_mean.iloc[0])-base)
fig,ax=plt.subplots(figsize=(10.5,5.8)); x=np.arange(len(delta)); ax.bar(x,delta); ax.axhline(0,linewidth=1); ax.set_xticks(x); ax.set_xticklabels(labels,rotation=20,ha="right"); ax.set_ylabel(r"$\Delta$MCC relative to complete CF-MAQL"); ax.set_title("Structural ablation analysis"); ax.grid(axis="y",alpha=.25)
for i,v in enumerate(delta): ax.text(i,v-.006 if v<0 else v+.001,f"{v:.3f}",ha="center",va="top" if v<0 else "bottom",fontsize=9)
fig.tight_layout(); fig.savefig(FIG/"Figure_8_E5_Structural_Ablation_Delta_MCC.png",dpi=600,bbox_inches="tight"); plt.close(fig)

print(f"Figures written to: {FIG}")
