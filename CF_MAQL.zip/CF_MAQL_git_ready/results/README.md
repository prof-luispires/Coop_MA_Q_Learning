# Experimental results

The result files in this directory are the stored outputs used for the manuscript analysis.

- **E1_E2**: CF-MAQL IID/cooperative-learning runs, validation threshold search, family recall, and paired differences.
- **E1_ML_baselines**: Random Forest, XGBoost, RBF-SVM, and MLP benchmark summaries and per-run metrics.
- **E3_LOAFO**: leave-one-attack-family-out evaluation, including the unseen-family recall matrix and paired comparisons.
- **E5_ablation**: structural ablations, component importance, per-run metrics, and paired comparisons.
- **consolidated**: master E1–E5 table and final paired statistical analysis. E4 partial-view robustness is included in the consolidated master results.

The five experimental seeds are 11, 22, 33, 44, and 55. Statistical comparisons use paired runs. With only five paired observations, p-values should be interpreted together with paired direction and effect sizes.
